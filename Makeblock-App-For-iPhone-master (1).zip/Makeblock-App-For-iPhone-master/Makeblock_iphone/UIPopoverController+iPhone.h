//
//  UIPopoverController+iPhone.h
//  Makeblock_Iphone
//
//  Created by Riven on 14-9-5.
//  Copyright (c) 2014年 Makeblock. All rights reserved.
//

#import <Foundation/Foundation.h>

// UIPopoverController+iPhone.h file
@interface UIPopoverController (iPhone)
+ (BOOL)_popoversDisabled;
@end
