//
//  SidebarModuleCell.h
//  Makeblock_Iphone
//
//  Created by Riven on 14-9-4.
//  Copyright (c) 2014年 Makeblock. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SidebarModuleCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *modImage;
@property (weak, nonatomic) IBOutlet UILabel *modLabel;

@end
