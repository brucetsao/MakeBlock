//
//  MWProjectCreateTableViewCell.h
//  Makeblock HD
//
//  Created by 虎子哥 on 14-3-25.
//  Copyright (c) 2014年 Makerworks. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MWProjectCreateTableViewCell : UITableViewCell
@property(weak,nonatomic)IBOutlet UILabel *infoLabel;
@end
