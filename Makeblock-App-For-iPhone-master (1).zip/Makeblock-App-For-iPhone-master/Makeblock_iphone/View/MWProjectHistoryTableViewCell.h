//
//  MWProjectHistoryTableViewCell.h
//  Makeblock HD
//
//  Created by 虎子哥 on 14-3-25.
//  Copyright (c) 2014年 Makerworks. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MWProjectHistoryTableViewCell : UITableViewCell
@property(nonatomic,weak)IBOutlet UILabel*titleLabel;
@property(nonatomic,weak)IBOutlet UILabel*dateLabel;
@end
