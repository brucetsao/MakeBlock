//
//  MWProjectCreateTableViewCell.m
//  Makeblock HD
//
//  Created by 虎子哥 on 14-3-25.
//  Copyright (c) 2014年 Makerworks. All rights reserved.
//

#import "MWProjectCreateTableViewCell.h"

@implementation MWProjectCreateTableViewCell

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
