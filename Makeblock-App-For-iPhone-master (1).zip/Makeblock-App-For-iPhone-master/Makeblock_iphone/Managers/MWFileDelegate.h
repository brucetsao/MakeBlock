//
//  MWFileDelegate.h
//  Makeblock_iphone
//
//  Created by 虎子哥 on 15/2/26.
//  Copyright (c) 2015年 Makeblock. All rights reserved.
//

#ifndef Makeblock_iphone_MWFileDelegate_h
#define Makeblock_iphone_MWFileDelegate_h

@protocol MWFileDelegate

- (void)loadedFile:(NSData*)data;

@end
#endif
