//
//  ProjectCell.h
//  Makeblock_Iphone
//
//  Created by Riven on 14-9-1.
//  Copyright (c) 2014年 Makeblock. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProjectCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *ProjectName;
@property (weak, nonatomic) IBOutlet UILabel *ModifyDate;

@end
