//
//  MWCalendarUtil.h
//  Makeblock HD
//
//  Created by 虎子哥 on 14-3-28.
//  Copyright (c) 2014年 Makerworks. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MWCalendarUtil : NSObject

+(NSString*)stringFromDate:(NSDate*)date withFormat:(NSString *)format;
@end
