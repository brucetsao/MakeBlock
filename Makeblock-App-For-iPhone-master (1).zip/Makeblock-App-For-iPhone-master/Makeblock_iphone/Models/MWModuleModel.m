//
//  MWModuleModel.m
//  Makeblock HD
//
//  Created by 虎子哥 on 14-3-27.
//  Copyright (c) 2014年 Makerworks. All rights reserved.
//

#import "MWModuleModel.h"

@implementation MWModuleModel
@dynamic createTime,updateTime,mid,name,pid,pin,port,slot,index,protocol,type,xPosition,yPosition,thumb,xib,menu,minValue,maxValue,displayMode,autoReset;
@end
