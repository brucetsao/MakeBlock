//
//  MWUserModel.m
//  Makeblock HD
//
//  Created by 虎子哥 on 14-3-27.
//  Copyright (c) 2014年 Makerworks. All rights reserved.
//

#import "MWUserModel.h"

@implementation MWUserModel
@dynamic createTime,updateTime,name,uid,device;
@end
