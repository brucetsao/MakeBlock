//
//  MWProjectModel.m
//  Makeblock HD
//
//  Created by 虎子哥 on 14-3-27.
//  Copyright (c) 2014年 Makerworks. All rights reserved.
//

#import "MWProjectModel.h"

@implementation MWProjectModel
@dynamic createTime,updateTime,uid,name,pid,imageLocal,imageUrl,type,tag;
@end
