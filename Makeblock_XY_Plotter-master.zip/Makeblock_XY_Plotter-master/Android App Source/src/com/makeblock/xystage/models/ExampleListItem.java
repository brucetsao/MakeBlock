package com.makeblock.xystage.models;

/**
 * Created with IntelliJ IDEA.
 * User: Administrator
 * Date: 13-10-5
 * Time: 上午11:19
 * To change this template use File | Settings | File Templates.
 */
public class ExampleListItem {
}
